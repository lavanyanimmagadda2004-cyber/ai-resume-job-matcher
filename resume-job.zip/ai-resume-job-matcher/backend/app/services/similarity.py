import numpy as np
from sentence_transformers import SentenceTransformer

class SimilarityEngine:
    def __init__(self, model_name: str):
        self.model = SentenceTransformer(model_name)

    def score(self, resume_text: str, jd_text: str) -> float:
        emb = self.model.encode([resume_text, jd_text], normalize_embeddings=True)
        r, j = emb[0], emb[1]
        sim = float(np.dot(r, j))
        sim = max(0.0, min(1.0, sim))
        return sim
